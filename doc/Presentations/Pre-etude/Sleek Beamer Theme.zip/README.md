SLEEK Beamer Theme
=================
The [Beamer Classes](http://www.tex.ac.uk/CTAN/macros/latex/contrib/beamer/doc/beameruserguide.pdf) for LaTeX is used to create presentations that are to be shown with a projector. The text typesetting system creates PDF files.
	
The theme for projectors presented here, adapted from HSRM theme by Benjamin Weiss, makes the creation of slides (assuming basic knowledge of LaTeX) child's play.

The SLEEK theme is licensed under the [GNU Public License](http://www.gnu.org/licenses/gpl-3.0.en.html). It may be redistributed and modified as long as the licence type is maintained.

If you have any questions or comments, please do not hesitate to contact me at the following e-mail address.

[up201806093@up.pt](mailto:up201806093@up.pt)